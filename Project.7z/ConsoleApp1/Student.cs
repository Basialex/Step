﻿namespace Programm
{
    internal class Student
    {
    }
}